**Discord Information:**
Channel: https://discord.gg/mBUCBvw3P9
Friend: kintaro_oe

**App Downloads:**
Full App Version:
https://github.com/KintaroEB/POE-2-Assistance

Full Pack with Effect Changes (No Account Required):
https://secure.eu.internxt.com/d/sh/folder/86d6505e-798f-45f5-8487-31a7ac28f2d9/f8119b0d1cc4554a96273a4392e7271de52352fa69b4d86ff23386f85d7aca80

Full Pack with Effect Changes (Google Account Required for Selective Download):
https://drive.google.com/drive/folders/1Aln9BIEHeK7Cgv_VJWs5UxWgE7z3N6Ba?usp=sharing

**Instructions:**
Extract all .dat files into:
"...\dependencies\advanced"


**THANK YOU VERY MUCH FOR THE SUPPORT!**