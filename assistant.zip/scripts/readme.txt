USAGE - remove the "prefix" so the final name is "THREAD__UTILITY.AHK" .
Copy into main folder and replace the original one. Maybe make a backup if you want to swap!


--------------------------------------------------------------------------------------------
For Life/Es hybrid builds:
HYBRID__THREAD__AUTOPOT (have Use Energy Shield checked in the GUI)
	- will use life flask on low ES
	- will use logout/escape on low life

For Mana based builds:
MOM__THREAD__AUTOPOT (GUI settings are as normal with life based)
	- will use logout/escape on low mana

For Temporal Rift usage when reaching low life:
LOWLIFE__THREAD__TEMPORALRIFT.AHK
	- will use Temporal Rift if reaching below 900 HP (an example code)
	- enable the thread in config.ini first
	- change the hp value and key for temporal rift if needed

--------------------------------------------------------------------------------------------