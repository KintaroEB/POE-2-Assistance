**Discord Information:**
Server: https://discord.gg/mBUCBvw3P9
ID: kintaro_oe

KOOK: https://kook.vip/siCxe5
ID: kintaro_oe#3654

**App Downloads:**
https://github.com/KintaroEB/POE-2-Assistance

**DOWNLOAD**: [pCloud Drive](https://e.pcloud.link/publink/show?code=kZpwFKZSErKbR1wc6uLxS0GWvHKJH1r4KGy)
**DOWNLOAD**: [Google Drive](https://drive.google.com/drive/folders/1Aln9BIEHeK7Cgv_VJWs5UxWgE7z3N6Ba)
**DOWNLOAD**: [Dropbox](https://www.dropbox.com/scl/fo/yeygl6hj58xlsv4gcy0rs/AKbbW6rgodwIIB2eWJDaCh0?rlkey=sk56mszepf73mjsz8n938clh0)

**Instructions:**
Extract all .ggpx files into:
"...\dependencies\advanced"


**THANK YOU VERY MUCH FOR THE SUPPORT!**