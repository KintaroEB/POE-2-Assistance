Discord Information:
Server: https://discord.gg/mBUCBvw3P9
ID: kintaro_oe

KOOK: https://kook.vip/RN1LFQ
ID: kintaro_oe#3654


GENERAL DOWNLOAD HUB
https://kintaro.top/dependencies/dependencies

ALWAYS - CURRENT VERSION
https://github.com/KintaroEB/POE-2-Assistance/raw/refs/heads/main/assistant.zip

DOWNLOADER
https://kintaro.top/dependencies/dependencies/_Downloader

DRIVERS AND DEPENDENCIES
https://kintaro.top/dependencies/dependencies/Driver

GGPX FILES FOR PAID FEATURES
https://kintaro.top/dependencies/dependencies/Advanced

TUTORIAL VIDEOS - START TO FINISH
https://kintaro.top/dependencies/dependencies/Tutorial


THANK YOU VERY MUCH FOR THE SUPPORT!