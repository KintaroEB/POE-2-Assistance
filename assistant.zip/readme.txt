**Discord Information:**
Server: https://discord.gg/mBUCBvw3P9
ID: kintaro_oe

KOOK: https://kook.vip/siCxe5
ID: kintaro_oe#3654

**App Downloads:**
https://github.com/KintaroEB/POE-2-Assistance


**GGPX Downloads:**
**DOWNLOAD**: [Google Drive](https://drive.google.com/drive/folders/1Aln9BIEHeK7Cgv_VJWs5UxWgE7z3N6Ba)
**DOWNLOAD**: [Dropbox](https://www.dropbox.com/scl/fo/yeygl6hj58xlsv4gcy0rs/AKbbW6rgodwIIB2eWJDaCh0?rlkey=sk56mszepf73mjsz8n938clh0)
**DOWNLOAD**: [InternXT](https://secure.internxt.com/d/sh/folder/6785aa5f-6bae-4857-a93e-d0e68c4a046c/fee8759e920a74832f4e8e5963e7fcfe8ab4e665bd6c3d4548aa7664e29d5c61)

**Instructions:**
Extract all .ggpx files into:
"...\dependencies\advanced\"


**THANK YOU VERY MUCH FOR THE SUPPORT!**